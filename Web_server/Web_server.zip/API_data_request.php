<?php 
$json = '[
{"team": "Benitez", "local":"LPAE", "volume":"900ml", "color":"red", "date":"16-08-2018 19:36"},
{"team": "Elvis", "local":"LPT", "volume":"850ml", "color":"blue", "date":"16-08-2018 19:35"},
{"team": "Benitez", "local":"LPAE", "volume":"875ml", "color":"red", "date":"15-08-2018 19:32"},
{"team": "Benitez", "local":"LPAE", "volume":"870ml", "color":"red", "date":"15-08-2018 19:21"},
{"team": "Ednei", "local":"LD1", "volume":"300ml", "color":"blue", "date":"15-08-2018 15:01"},
{"team": "Ednei", "local":"LD1", "volume":"550ml", "color":"green", "date":"15-08-2018 15:00"}
]';
echo $json; ?>